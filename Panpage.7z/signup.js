function loginSuccess() {
    alert("회원가입을 축하합니다.")
    location.href="index2.html";
}