var list1;
var list2;
var list3;
var list4;
var list5;
var list6;
var list7;
var list8;
var list9;
var list10;
var list11;
var list12;
var main;

list1 = document.getElementById("list1_content");
list2 = document.getElementById("list2_content");
list3 = document.getElementById("list3_content");
list4 = document.getElementById("list4_content");
list5 = document.getElementById("list5_content");
list6 = document.getElementById("list6_content");
list7 = document.getElementById("list7_content");
list8 = document.getElementById("list8_content");
list9 = document.getElementById("list9_content");
list10 = document.getElementById("list10_content");
list11 = document.getElementById("list11_content");
list12 = document.getElementById("list12_content");
main = document.getElementById("main_back");



function listClick1() {
    if(list1.style.display=="none") {
        list1.style.display="block";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list1.style.display="none";
        main.style.display="block";
    }
};

function listClick2() {
    if(list2.style.display=="none") {
        list1.style.display="none";
        list2.style.display="block";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list2.style.display="none";
        main.style.display="block";
    }
};

function listClick3() {
    if(list3.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="block";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list3.style.display="none";
        main.style.display="block";
    }
};

function listClick4() {
    if(list4.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="block";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list4.style.display="none";
        main.style.display="block";
    }
};

function listClick5() {
    if(list5.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="block";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list5.style.display="none";
        main.style.display="block";
    }
};

function listClick6() {
    if(list6.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="block";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list6.style.display="none";
        main.style.display="block";
    }
};

function listClick7() {
    if(list7.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="block";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list7.style.display="none";
        main.style.display="block";
    }
};

function listClick8() {
    if(list8.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="block";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list8.style.display="none";
        main.style.display="block";
    }
};

function listClick9() {
    if(list9.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="block";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list9.style.display="none";
        main.style.display="block";
    }
};

function listClick10() {
    if(list10.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="block";
        list11.style.display="none";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list10.style.display="none";
        main.style.display="block";
    }
};

function listClick11() {
    if(list11.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="block";
        list12.style.display="none";
        main.style.display="none";
    } else {
        list11.style.display="none";
        main.style.display="block";
    }
};

function listClick12() {
    if(list12.style.display=="none") {
        list1.style.display="none";
        list2.style.display="none";
        list3.style.display="none";
        list4.style.display="none";
        list5.style.display="none";
        list6.style.display="none";
        list7.style.display="none";
        list8.style.display="none";
        list9.style.display="none";
        list10.style.display="none";
        list11.style.display="none";
        list12.style.display="block";
        main.style.display="none";
        main.style.display="none";
    } else {
        list12.style.display="none";
        main.style.display="block";
    }
};
